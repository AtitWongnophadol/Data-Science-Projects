"""In this turn-base game in which the player who takes the last turn
loses the game as the player hits the number below 1, we can define 
a function to determines which of the two players
will always win or lose. There are the starter, and the follower.
The function win(n) below takes "n" as the starting number of
the game and determine whether the number hits the losing condition (<0),
or else it returns the result of the subsequent movement according to
the rule of the game, which is the number in the next round is either
(n-1) or (n/2). This subsequent result is from the current player 
perspective, and therefore the function returns the opposite of the
outcome in the subsequent move.
"""
 
def win(n): #define the function to take n as an input
    if n<1: 
        #If n is below 1, then the player loses the game.
        #In this case, return False to indicate the losing status.
        return False 
    else:
        #The next condition simply says that for the current player to win
        #the subsequent player must lose regardless of the path it takes.
        #If there is at least one path the subsequent player can win, then
        #the current player will always lose the game.
        
        #For example, if either choice below (n-1 vs. n/2) leads to 
        #a winning status of the subsequent player, then it means losing
        #to the current player (thus the "not" operator in front of the
        #choices.
        
        #Alternatively, if one of the two paths leads to a win for the
        #subsequent player, then it means a lose to the current player;
        #in which case the function return False.
        
        return not(win(n-1) or win(n/2))

#Define starting number of the game
n=7

#As the function return the status of the subsequent player's,
#The False outcome of the function win(n) means a win for the starter.
#Likewise, the True outcome of the function means a win for the follower.
print("If n is "+str(n)+", then the winner is the "+("follower." if win(n) else "starter." ))
   
   
#For the loop below is used to test the program for first several n(s).
#for i in range(1,n+1,1):
#    print("If n is "+str(i)+", then the winner is the "+("follower" if win(i) else "starter" ))
    